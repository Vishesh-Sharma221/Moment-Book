from MomentBook.cli import *

menu()   
main()